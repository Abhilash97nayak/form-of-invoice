from django.shortcuts import render,HttpResponse
from home.models import invoice

# Create your views here.
def invoice(request):
    if request.method == "POST":
        buyername=request.POST.get('bname')
        sellername=request.POST.get('sname')
        buyeraddress=request.POST.get('baddress')
        selleraddress=request.POST.get('saddress')
        buyerno=request.POST.get('bno')
        sellerno=request.POST.get('sno')
        slno=request.POST.get('sl1')
        product=request.POST.get('p1')
        quantity=request.POST.get('q1')
        amount=request.POST.get('a1')
        estimate=request.POST.get('add')
        Invoice = invoice(buyername=buyername,sellername=sellername,buyeraddress=buyeraddress,selleraddress=selleraddress,buyerno=buyerno,sellerno=sellerno,slno=slno,product=product,quantity=quantity,amount=amount,estimate=estimate)
        Invoice.save()
        

    return render(request,'invoice.html')


