from django.db import models

# Create your models here.
class invoice(models.Model):
    buyername=models.CharField(max_length=120)
    sellername=models.CharField(max_length=120)
    buyeraddress=models.CharField(max_length=220)
    selleraddress=models.CharField(max_length=220)
    buyerno=models.IntegerField()
    sellerno=models.IntegerField()
    slno=models.IntegerField()
    product=models.CharField(max_length=120)
    amount=models.IntegerField()
    quantity=models.IntegerField()
    estimate=models.IntegerField()